<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
<head>
    <title><?php echo CHtml::encode($this->pageTitle); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/css/style.css" media="screen, projection" />
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/form.css" />
</head>
<body>
<div class="content">
  <div id="header">
    <div class="title">
      <h1>sNEWS 1.5</h1>
      <h3>USE THIS TEMPLATE FOR FREE!</h3>
    </div>
  </div>
  <div id="main">
    <div class="center">
        <?php echo $content; ?>
      <!-- LEFT IT HERE FOR EXAMPLE
      <h2><a href="http://www.free-css.com/">Manuscript Template</a></h2>
      <h3>YOUR NEWS ON A OLD PAPER</h3>
      Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec sem. Praesent eu metus. Vivamus ac urna. Maecenas tincidunt libero id ipsum. Duis ipsum erat, laoreet in, ultrices at, blandit non, enim. Maecenas et libero. In laoreet vehicula enim. Nam at massa. Donec porttitor, odio id scelerisque pretium, augue eros cursus est, eget interdum dui justo et tellus. Aenean a neque eu mauris ultrices viverra. In ac urna. Etiam in dolor sit amet arcu auctor interdum. Fusce non quam. Nunc aliquet, quam eu facilisis venenatis, pede augue adipiscing lorem, nec tincidunt nunc felis eget odio. Integer iaculis pretium odio. Integer viverra. Integer porttitor elementum diam. In hac habitasse platea dictumst. Donec porta elit.
      <p class="date">Posted by Jack <img src="images/more.gif" alt="" /> <a href="http://www.free-css.com/">Read more</a> <img src="images/comment.gif" alt="" /> <a href="http://www.free-css.com/">Comments (15)</a> <img src="images/timeicon.gif" alt="" /> 17.01.</p>
      <br />
      <h2><a href="http://www.free-css.com/">Try it with sNews 1.4</a></h2>
      <h3>AND WHY NOT WITH sNEWS 1.5 ;-)</h3>
      Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec sem. Praesent eu metus. Vivamus ac urna. Maecenas tincidunt libero id ipsum. Duis ipsum erat, laoreet in, ultrices at, blandit non, enim. Maecenas et libero. In laoreet vehicula enim. Nam at massa. Donec porttitor, odio id scelerisque pretium, augue eros cursus est, eget interdum dui justo et tellus. Aenean a neque eu mauris ultrices viverra. In ac urna. Etiam in dolor sit amet arcu auctor interdum. Fusce non quam. Nunc aliquet, quam eu facilisis venenatis, pede augue adipiscing lorem, nec tincidunt nunc felis eget odio. Integer iaculis pretium odio. Integer viverra. Integer porttitor elementum diam. In hac habitasse platea dictumst. Donec porta elit.
      <p class="date">Posted by Jack <img src="images/more.gif" alt="" /> <a href="http://www.free-css.com/">Read more</a> <img src="images/comment.gif" alt="" /> <a href="http://www.free-css.com/">Comments (15)</a> <img src="images/timeicon.gif" alt="" /> 17.01.</p>
      <br />
      -->
    </div>
    <div class="leftmenu">
      <div class="nav">
					<?php
                        $userVisible = Yii::app()->user->checkAccess('createUser') || Yii::app()->user->checkAccess('indexAllUser');

						$itemsProject = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuProject.php');
						$itemsTask = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuTask.php');
						$itemsUser = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuUser.php');
						$itemsCharge = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuCharge.php');
						$itemsRole = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuAuth.php');
						$itemsConfig = array(
    array('label' => Yii::t('nav', 'System'), 'itemOptions' => array('class' => 'has-submenu'), 'items' => array(
            array('label' => Yii::t('nav', 'Application'), 'url' => array('/config')),
            array('label' => Yii::t('nav', 'Backups'), 'url' => array('/databaseBackup')),
        )),
    array('label' => Yii::t('nav', 'Tasks'), 'itemOptions' => array('class' => 'has-submenu'), 'items' => array(
            array('label' => Yii::t('nav', 'Task Status'), 'url' => array('/taskStatus')),
            array('label' => Yii::t('nav', 'Task Type'), 'url' => array('/taskType')),
        )),
    array('label' => Yii::t('nav', 'Check for update'), 'url' => array('/checkUpdate')),
);

						$this->widget('zii.widgets.CMenu', array(
							'htmlOptions' => array('class' => 'drop'),
								'items' => array(
									array('label' => Yii::t('nav', 'Home'), 'itemOptions' => array('class' => 'menuitem'), 'url' => array('/site/index')),

									array('label' => Yii::t('nav', 'Projects'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['Project']) && Yii::app()->params['tabs']['Project'],
										'items' => $itemsProject,
									),
									array('label' => Yii::t('nav', 'Tasks'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['Task']) && Yii::app()->params['tabs']['Task'],
										'items' => $itemsTask,
						        	),
									array('label' => Yii::t('nav', 'Users'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['User']) && Yii::app()->params['tabs']['User'] && $userVisible,
										'items' => $itemsUser,
						        	),
									array('label' => Yii::t('nav', 'Charges'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['Charge']) && Yii::app()->params['tabs']['Charge'],
										'items' => $itemsCharge,
									),
									array('label' => Yii::t('nav', 'Roles'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']) && Yii::app()->params['tabs']['Authorization'] && Yii::app()->user->checkAccess('adminRole'),
										'items' => $itemsRole,
									),
									array(
										'label' => Yii::t('nav', 'Config'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'),
										'visible' => !Yii::app()->user->isGuest && Yii::app()->user->checkAccess('adminConfig'),
										'items' => $itemsConfig,
									),
									array(
										'label' => Yii::app()->user->name, 'url' => '#', 'itemOptions' => array('class' => 'has-submenu right-align'), // 右寄せ用のクラスを追加
										'visible' => !Yii::app()->user->isGuest,
										'items' => array(
										array('label' => Yii::t('nav', 'My Profile'), 'url' => array('/userAccount')),
										array('label' => Yii::t('nav', 'Edit Profile'), 'url' => array('/userAccount/update')),
										array('label' => Yii::t('nav', 'Logout'), 'url' => array('/site/logout')),
									),
								),

							),
						)); 

					?>

					<style>
						.drop {
							display: flex; /* フレックスボックスを使用 */
							list-style-type: none; /* デフォルトのリストスタイルを削除 */
							padding: 0; /* パディングをリセット */
							margin: 0; /* マージンをリセット */
							justify-content: space-between; /* メニュー項目を左右に分散 */
						}

						.menuitem, .has-submenu {
							position: relative; /* サブメニューの位置を制御するため */
						}

						.menuitem > a, .has-submenu > a {
							padding: 10px 15px; /* メニュー項目の内側の余白 */
							display: block; /* ブロック要素として表示 */
							color: white; /* フォントの色を白に設定 */
							white-space: nowrap; /* テキストを改行しない */
						}

						.has-submenu > ul {
							list-style-type: none; /* デフォルトのリストスタイルを削除 */
							display: none; /* サブメニューを非表示 */
							position: absolute; /* サブメニューを親の下に配置 */
							top: 100%; /* 親メニューの下に配置 */
							left: 0; /* 左揃え */
							width: 130px; /* サブメニューの幅 */
							padding: 0; /* パディングをリセット */
							margin: 0; /* マージンをリセット */
							z-index: 1000; /* 他の要素より上に表示 */
							background-color: #fff; /* サブメニューの背景色を設定 */
						}

						.menuitem > a:hover, .has-submenu > a:hover {
						    color: #ccc; /* ホバー時に色を変更（オプション） */
						}

						.has-submenu:hover > ul {
						    display: block; /* ホバー時にサブメニューを表示 */
						}

						.has-submenu > ul > li > a {
						    color: black; /* サブメニューのフォントの色を黒に設定 */
						}

						/* ネストされたサブメニューのスタイル */
						.has-submenu > ul > li.has-submenu > a {
							position: relative;
						}

						.has-submenu > ul > li.has-submenu > ul {
							display: none; /* ネストされたサブメニューを非表示 */
							position: absolute; /* 親の右に配置 */
							left: 100%; /* 親の右に揃える */
							top: 0; /* 上に揃える */
						}

						.has-submenu > ul > li.has-submenu:hover > ul {
							display: block; /* ホバー時にネストされたサブメニューを表示 */
						}

						/* 右寄せのスタイル */
						.right-align {
							margin-left: auto; /* 左側のマージンを自動にして右寄せ */
						}
						</style>

						<script>
						$(document).ready(function() {
							 $('.has-submenu > a').click(function(e) {
								e.preventDefault(); // デフォルトのリンク動作を防止
								$(this).siblings('ul').toggle(); // サブメニューの表示/非表示を切り替え
							});
						});
						</script>

			        <style>
.has-submenu > ul {
    display: none; /* サブメニューを非表示 */
}
			        </style>
<script>
$(document).ready(function() {
    $('.has-submenu > a').click(function(e) {
        e.preventDefault(); // デフォルトのリンク動作を防止
        $(this).siblings('ul').toggle(); // サブメニューの表示/非表示を切り替え
    });
});
</script>

      </div>
    </div>
  </div>
  <div id="prefooter">
    <div class="particles">
      <h2>Top Articles</h2>
      <img src="<?php echo Yii::app()->theme->baseUrl; ?>/images/arrow.gif" alt="" /> <a href="http://www.free-css.com/">Integer euismod ante non diam adipiscing</a> <br />
      <img src="<?php echo Yii::app()->theme->baseUrl; ?>/images/arrow.gif" alt="" /> <a href="http://www.free-css.com/">consectetuer adipiscing elit dolor sit amet</a> <br />
      <img src="<?php echo Yii::app()->theme->baseUrl; ?>/images/arrow.gif" alt="" /> <a href="http://www.free-css.com/">Lorem ipsum dolor sit amet ipsum dolor</a><br />
      <img src="<?php echo Yii::app()->theme->baseUrl; ?>/images/arrow.gif" alt="" /> <a href="http://www.free-css.com/">Integer euismod ante non adipiscing elit </a><br />
      <img src="<?php echo Yii::app()->theme->baseUrl; ?>/images/arrow.gif" alt="" /> <a href="http://www.free-css.com/">Lorem ipsum dolor sit amet euismod ante</a><br />
    </div>
    <div class="comments">
      <h2>Last Comments</h2>
      <img src="<?php echo Yii::app()->theme->baseUrl; ?>/images/arrow.gif" alt="" /> <a href="http://www.free-css.com/">Integer euismod ante non diam adipiscing</a> <br />
      <img src="<?php echo Yii::app()->theme->baseUrl; ?>/images/arrow.gif" alt="" /> <a href="http://www.free-css.com/">consectetuer adipiscing elit dolor sit amet</a> <br />
      <img src="<?php echo Yii::app()->theme->baseUrl; ?>/images/arrow.gif" alt="" /> <a href="http://www.free-css.com/">Lorem ipsum dolor sit amet ipsum dolor</a><br />
      <img src="<?php echo Yii::app()->theme->baseUrl; ?>/images/arrow.gif" alt="" /> <a href="http://www.free-css.com/">Integer euismod ante non adipiscing elit </a><br />
      <img src="<?php echo Yii::app()->theme->baseUrl; ?>/images/arrow.gif" alt="" /> <a href="http://www.free-css.com/">Lorem ipsum dolor sit amet euismod ante</a><br />
    </div>
  </div>
  <div id="footer">
    <div class="padding"> Copyright &copy; <?php echo date( 'Y', time() ) . ' ' . CHtml::encode( Yii::app()->name ); ?>    
    | Design: <a href="http://www.free-css-templates.com">David Herreman </a> | <a href="http://www.free-css.com/">Contact</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a> and <a href="http://validator.w3.org/check?uri=referer">XHTML</a> | <a href="http://www.solucija.com">Solucija.com</a> | <a href="http://www.free-css.com/">Login</a> </div>
  </div>
</div>
</body>
</html>
