<?php
	Yii::app()->clientscript
		// use it when you need it!
		/*
		->registerCssFile( Yii::app()->theme->baseUrl . '/css/bootstrap.css' )
		->registerCssFile( Yii::app()->theme->baseUrl . '/css/bootstrap-responsive.css' )
		->registerCoreScript( 'jquery' )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-transition.js', CClientScript::POS_END )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-alert.js', CClientScript::POS_END )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-modal.js', CClientScript::POS_END )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-dropdown.js', CClientScript::POS_END )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-scrollspy.js', CClientScript::POS_END )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-tab.js', CClientScript::POS_END )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-tooltip.js', CClientScript::POS_END )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-popover.js', CClientScript::POS_END )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-button.js', CClientScript::POS_END )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-collapse.js', CClientScript::POS_END )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-carousel.js', CClientScript::POS_END )
		->registerScriptFile( Yii::app()->theme->baseUrl . '/js/bootstrap-typeahead.js', CClientScript::POS_END )
		*/
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo CHtml::encode($this->pageTitle); ?></title>
<meta name="language" content="en" />
<!-- Le HTML5 shim, for IE6-8 support of HTML elements -->
<!--[if lt IE 9]>
<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<!-- Le styles -->
<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/css/bootstrap.css" />
<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/css/bootstrap-responsive.css" />
<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl; ?>/css/style.css" />
<!-- Le fav and touch icons -->
</head>

<body>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="navbar-inner">
			<div class="container-fluid">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
				<a class="brand" href="#"><?php echo Yii::app()->name ?></a>
				<div class="nav-collapse">
					<?php
                        $userVisible = Yii::app()->user->checkAccess('createUser') || Yii::app()->user->checkAccess('indexAllUser');

						$itemsProject = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuProject.php');
						$itemsTask = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuTask.php');
						$itemsUser = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuUser.php');
						$itemsCharge = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuCharge.php');
						$itemsRole = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuAuth.php');
						$itemsConfig = array(
    array('label' => Yii::t('nav', 'System'), 'itemOptions' => array('class' => 'has-submenu'), 'items' => array(
            array('label' => Yii::t('nav', 'Application'), 'url' => array('/config')),
            array('label' => Yii::t('nav', 'Backups'), 'url' => array('/databaseBackup')),
        )),
    array('label' => Yii::t('nav', 'Tasks'), 'itemOptions' => array('class' => 'has-submenu'), 'items' => array(
            array('label' => Yii::t('nav', 'Task Status'), 'url' => array('/taskStatus')),
            array('label' => Yii::t('nav', 'Task Type'), 'url' => array('/taskType')),
        )),
    array('label' => Yii::t('nav', 'Check for update'), 'url' => array('/checkUpdate')),
);

						$this->widget('zii.widgets.CMenu', array(
							'htmlOptions' => array('class' => 'drop'),
								'items' => array(
									array('label' => Yii::t('nav', 'Home'), 'itemOptions' => array('class' => 'menuitem'), 'url' => array('/site/index')),

									array('label' => Yii::t('nav', 'Projects'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['Project']) && Yii::app()->params['tabs']['Project'],
										'items' => $itemsProject,
									),
									array('label' => Yii::t('nav', 'Tasks'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['Task']) && Yii::app()->params['tabs']['Task'],
										'items' => $itemsTask,
						        	),
									array('label' => Yii::t('nav', 'Users'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['User']) && Yii::app()->params['tabs']['User'] && $userVisible,
										'items' => $itemsUser,
						        	),
									array('label' => Yii::t('nav', 'Charges'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['Charge']) && Yii::app()->params['tabs']['Charge'],
										'items' => $itemsCharge,
									),
									array('label' => Yii::t('nav', 'Roles'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']) && Yii::app()->params['tabs']['Authorization'] && Yii::app()->user->checkAccess('adminRole'),
										'items' => $itemsRole,
									),
									array(
										'label' => Yii::t('nav', 'Config'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'),
										'visible' => !Yii::app()->user->isGuest && Yii::app()->user->checkAccess('adminConfig'),
										'items' => $itemsConfig,
									),
									array(
										'label' => Yii::app()->user->name, 'url' => '#', 'itemOptions' => array('class' => 'has-submenu right-align'), // 右寄せ用のクラスを追加
										'visible' => !Yii::app()->user->isGuest,
										'items' => array(
										array('label' => Yii::t('nav', 'My Profile'), 'url' => array('/userAccount')),
										array('label' => Yii::t('nav', 'Edit Profile'), 'url' => array('/userAccount/update')),
										array('label' => Yii::t('nav', 'Logout'), 'url' => array('/site/logout')),
									),
								),

							),
						)); 

					?>

					<style>
						.drop {
							display: flex; /* フレックスボックスを使用 */
							list-style-type: none; /* デフォルトのリストスタイルを削除 */
							padding: 0; /* パディングをリセット */
							margin: 0; /* マージンをリセット */
							justify-content: space-between; /* メニュー項目を左右に分散 */
						}

						.menuitem, .has-submenu {
							position: relative; /* サブメニューの位置を制御するため */
						}

						.menuitem > a, .has-submenu > a {
							padding: 10px 15px; /* メニュー項目の内側の余白 */
							display: block; /* ブロック要素として表示 */
							color: white; /* フォントの色を白に設定 */
							white-space: nowrap; /* テキストを改行しない */
						}

						.has-submenu > ul {
							list-style-type: none; /* デフォルトのリストスタイルを削除 */
							display: none; /* サブメニューを非表示 */
							position: absolute; /* サブメニューを親の下に配置 */
							top: 100%; /* 親メニューの下に配置 */
							left: 0; /* 左揃え */
							width: 130px; /* サブメニューの幅 */
							padding: 0; /* パディングをリセット */
							margin: 0; /* マージンをリセット */
							z-index: 1000; /* 他の要素より上に表示 */
							background-color: #fff; /* サブメニューの背景色を設定 */
						}

						.menuitem > a:hover, .has-submenu > a:hover {
						    color: #ccc; /* ホバー時に色を変更（オプション） */
						}

						.has-submenu:hover > ul {
						    display: block; /* ホバー時にサブメニューを表示 */
						}

						.has-submenu > ul > li > a {
						    color: black; /* サブメニューのフォントの色を黒に設定 */
						}

						/* ネストされたサブメニューのスタイル */
						.has-submenu > ul > li.has-submenu > a {
							position: relative;
						}

						.has-submenu > ul > li.has-submenu > ul {
							display: none; /* ネストされたサブメニューを非表示 */
							position: absolute; /* 親の右に配置 */
							left: 100%; /* 親の右に揃える */
							top: 0; /* 上に揃える */
						}

						.has-submenu > ul > li.has-submenu:hover > ul {
							display: block; /* ホバー時にネストされたサブメニューを表示 */
						}

						/* 右寄せのスタイル */
						.right-align {
							margin-left: auto; /* 左側のマージンを自動にして右寄せ */
						}
						</style>

						<script>
						$(document).ready(function() {
							 $('.has-submenu > a').click(function(e) {
								e.preventDefault(); // デフォルトのリンク動作を防止
								$(this).siblings('ul').toggle(); // サブメニューの表示/非表示を切り替え
							});
						});
						</script>
				</div><!--/.nav-collapse -->
			</div>
		</div>
	</div>
	
	<div class="cont">
	<div class="container-fluid">
	  <?php if(isset($this->breadcrumbs)):?>
			<?php $this->widget('zii.widgets.CBreadcrumbs', array(
				'links'=>$this->breadcrumbs,
				'homeLink'=>false,
				'tagName'=>'ul',
				'separator'=>'',
				'activeLinkTemplate'=>'<li><a href="{url}">{label}</a> <span class="divider">/</span></li>',
				'inactiveLinkTemplate'=>'<li><span>{label}</span></li>',
				'htmlOptions'=>array ('class'=>'breadcrumb')
			)); ?>
		<!-- breadcrumbs -->
	  <?php endif?>
	
	<?php echo $content ?>
	
	
	</div><!--/.fluid-container-->
	</div>
		
	<div class="footer">
	  <div class="container">
		<div class="row" align="center">
        		Copyright &copy; 2014 - <?php echo date('Y'); ?> by <?php echo CHtml::link('MyT Team', 'http://sourceforge.net/projects/myt/'); ?>.<br/>
		        All Rights Reserved.<br/>
        		<?php echo Yii::powered(); ?>
			<div id="footer-terms" class="col-md-6">
				© 2012-13 Black Bootstrap. <a href="http://nachi.me.pn" target="_blank">Nachi</a>.
			</div> <!-- /.span6 -->
		 </div> <!-- /row -->
	  </div> <!-- /container -->
	</div>
</body>
</html>
