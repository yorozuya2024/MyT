<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	<title><?php echo $this->pageTitle ?></title>

	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/form.css" />
	<link rel="stylesheet" href="<?php echo Yii::app()->theme->baseUrl ?>/css/styles.css" type="text/css" media="screen" />
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->theme->baseUrl ?>/css/print.css" media="print" />

	<style type="text/css" media="screen">
		h1.fontface {font: 32px/38px 'MichromaRegular', Arial, sans-serif;letter-spacing: 0;}
		p.style1 {font: 18px/27px 'MichromaRegular', Arial, sans-serif;}
		@font-face {
			font-family: 'MichromaRegular';
			src: url('<?php echo Yii::app()->theme->baseUrl ?>/css/font/Michroma-webfont.eot');
			src: url('<?php echo Yii::app()->theme->baseUrl ?>/css/font/Michroma-webfont.eot?#iefix') format('embedded-opentype'),
			url('<?php echo Yii::app()->theme->baseUrl ?>/css/font/Michroma-webfont.woff') format('woff'),
			url('<?php echo Yii::app()->theme->baseUrl ?>/css/font/Michroma-webfont.ttf') format('truetype'),
			url('<?php echo Yii::app()->theme->baseUrl ?>/css/font/Michroma-webfont.svg#MichromaRegular') format('svg');
			font-weight: normal;
			font-style: normal;
		}
	</style>


	<!--[if IE]><script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
	
</head>
<body>


	  <header>
 <div class="container1">
    <!--start title-->
    <h1 class="fontface" id="title"><?php echo Yii::app()->name ?></h1>
	<!--end title-->
  </div>
    
	</header>
	<!--end header-->
 
	<nav>

	<div id="mainmenu">
		<?php
                        $userVisible = Yii::app()->user->checkAccess('createUser') || Yii::app()->user->checkAccess('indexAllUser');
			$items = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menu.php');

						$itemsProject = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuProject.php');
						$itemsTask = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuTask.php');
						$itemsUser = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuUser.php');
						$itemsCharge = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuCharge.php');
						$itemsRole = require(Yii::getPathOfAlias('application.views.menu') . DIRECTORY_SEPARATOR . 'menuAuth.php');
						$itemsConfig = array(
    array('label' => Yii::t('nav', 'System'), 'itemOptions' => array('class' => 'has-submenu'), 'items' => array(
            array('label' => Yii::t('nav', 'Application'), 'url' => array('/config')),
            array('label' => Yii::t('nav', 'Backups'), 'url' => array('/databaseBackup')),
        )),
    array('label' => Yii::t('nav', 'Tasks'), 'itemOptions' => array('class' => 'has-submenu'), 'items' => array(
            array('label' => Yii::t('nav', 'Task Status'), 'url' => array('/taskStatus')),
            array('label' => Yii::t('nav', 'Task Type'), 'url' => array('/taskType')),
        )),
    array('label' => Yii::t('nav', 'Check for update'), 'url' => array('/checkUpdate')),
);

						$this->widget('zii.widgets.CMenu', array(
							'htmlOptions' => array('class' => 'drop'),
								'items' => array(
									array('label' => Yii::t('nav', 'Home'), 'itemOptions' => array('class' => 'menuitem'), 'url' => array('/site/index')),
									array('label' => Yii::t('nav', 'Projects'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['Project']) && Yii::app()->params['tabs']['Project'],
										'items' => $itemsProject,
									),
									array('label' => Yii::t('nav', 'Tasks'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['Task']) && Yii::app()->params['tabs']['Task'],
										'items' => $itemsTask,
						        	),
									array('label' => Yii::t('nav', 'Users'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['User']) && Yii::app()->params['tabs']['User'] && $userVisible,
										'items' => $itemsUser,
						        	),
									array('label' => Yii::t('nav', 'Charges'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']['Charge']) && Yii::app()->params['tabs']['Charge'],
										'items' => $itemsCharge,
									),
									array('label' => Yii::t('nav', 'Roles'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'), 
										'visible' => !Yii::app()->user->isGuest && isset(Yii::app()->params['tabs']) && Yii::app()->params['tabs']['Authorization'] && Yii::app()->user->checkAccess('adminRole'),
										'items' => $itemsRole,
									),
									array(
										'label' => Yii::t('nav', 'Config'), 'url' => '#', 'itemOptions' => array('class' => 'has-submenu'),
										'visible' => !Yii::app()->user->isGuest && Yii::app()->user->checkAccess('adminConfig'),
										'items' => $itemsConfig,
									),
									array(
										'label' => Yii::app()->user->name, 'url' => '#', 'itemOptions' => array('class' => 'has-submenu right-align'), // 右寄せ用のクラスを追加
										'visible' => !Yii::app()->user->isGuest,
										'items' => array(
										array('label' => Yii::t('nav', 'My Profile'), 'url' => array('/userAccount')),
										array('label' => Yii::t('nav', 'Edit Profile'), 'url' => array('/userAccount/update')),
										array('label' => Yii::t('nav', 'Logout'), 'url' => array('/site/logout')),
									),
								),
							),
						)); 



		 ?>
					<style>
						.drop {
							display: flex; /* フレックスボックスを使用 */
							list-style-type: none; /* デフォルトのリストスタイルを削除 */
							padding: 0; /* パディングをリセット */
							margin: 0; /* マージンをリセット */
							justify-content: space-between; /* メニュー項目を左右に分散 */
						}


						.menuitem, .has-submenu {
							position: relative; /* サブメニューの位置を制御するため */
						}

						.menuitem > a, .has-submenu > a {
							color: #3D617E !important;
							padding: 10px 15px; /* メニュー項目の内側の余白 */
							display: block; /* ブロック要素として表示 */
							white-space: nowrap; /* テキストを改行しない */
							text-decoration: none; /* リンクの下線を削除 */
						}

						.has-submenu > ul {

							list-style-type: none; /* デフォルトのリストスタイルを削除 */
							display: none; /* サブメニューを非表示 */
							position: absolute; /* サブメニューを親の下に配置 */
							top: 100%; /* 親メニューの下に配置 */
							left: 0; /* 左揃え */
							width: 130px; /* サブメニューの幅 */
							padding: 0; /* パディングをリセット */
							margin: 0; /* マージンをリセット */
							z-index: 1000; /* 他の要素より上に表示 */
							background-color: #fff; /* サブメニューの背景色を設定 */

						}

						.menuitem > a:hover, .has-submenu > a:hover {
						    color: #ccc; /* ホバー時に色を変更（オプション） */
						}

						.has-submenu:hover > ul {
						    display: block; /* ホバー時にサブメニューを表示 */
						}

						.has-submenu > ul > li > a {
						    display: block; /* 縦方向にリストアイテムを配置 */
						    color: #3D617E !important; /* サブメニューのフォントの色を黒に設定 */
						}

						/* ネストされたサブメニューのスタイル */
						.has-submenu > ul > li.has-submenu > a {
							position: relative;

						}

						.has-submenu > ul > li.has-submenu {
							color: #3D617E !important;
						}

						.has-submenu > ul > li.has-submenu > ul {
							color: #3D617E !important;

							display: none; /* ネストされたサブメニューを非表示 */
							position: absolute; /* 親の右に配置 */
							left: 100%; /* 親の右に揃える */
							top: 0; /* 上に揃える */
						}

						.has-submenu > ul > li.has-submenu:hover > ul {
							display: block; /* ホバー時にネストされたサブメニューを表示 */
						}

						/* 右寄せのスタイル */
						.right-align {
							margin-left: auto; /* 左側のマージンを自動にして右寄せ */
						}
						</style>

						<script>
						$(document).ready(function() {
							 $('.has-submenu > a').click(function(e) {
								e.preventDefault(); // デフォルトのリンク動作を防止
								$(this).siblings('ul').toggle(); // サブメニューの表示/非表示を切り替え
							});
						});
						</script>

	</div><!-- mainmenu -->


    </nav>
	<div id="wrapper"><!-- #wrapper -->
	<section id="main"><!-- #main content -->
        

			<section id="content"><!-- #content -->

				<article class="group1">
					<?php echo $content ?>
				</article>


	</section><!-- end of #main content-->
</div>
		<footer>
		<div class="container1">
		<section id="footer-area">

			<section id="footer-outer-block">

					
					<aside class="footer-segment">
							<h4>Blahdyblah</h4>
								<p>&copy; 2010 <a href="#">yoursite.com</a> Praesent libero. Sed cursus ante dapibus diam. Sed nisi.</p>
					</aside><!-- end of #fourth footer segment -->

			</section><!-- end of footer-outer-block -->

		</section><!-- end of footer-area -->
		</div>
	</footer>
<!-- Free template distributed by http://freehtml5templates.com -->
</body>
</html>
