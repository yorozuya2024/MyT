/* MyT Database Backup for https://localhost/prj
 *  at 10/10/2024 13:21:07 
 */

SET FOREIGN_KEY_CHECKS = 0;

SET NAMES 'utf8';

/* Scheme for table myt_android_udid */
CREATE TABLE `myt_android_udid` (
  `user_name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `registration_id` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`registration_id`),
  KEY `myt_user_name` (`user_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

/* Scheme for table myt_attachment */
CREATE TABLE `myt_attachment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  `uri` text COLLATE utf8mb4_bin,
  `created` date DEFAULT NULL,
  `task_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `mega_id` char(8) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mega_id` (`mega_id`),
  KEY `myt_task_id` (`task_id`),
  KEY `myt_project_id` (`project_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

/* Scheme for table myt_auth_assignment */
CREATE TABLE `myt_auth_assignment` (
  `itemname` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `userid` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `bizrule` text COLLATE utf8mb4_bin,
  `data` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`itemname`,`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_auth_assignment` VALUES
('Application Manager','1',NULL,'N;'),
('Developer','1',NULL,'N;'),
('Developer','45',NULL,'N;'),
('Project Manager','1',NULL,'N;'),
('Role Manager','1',NULL,'N;'),
('Task Manager','1',NULL,'N;'),
('User Manager','1',NULL,'N;');
/* Scheme for table myt_auth_item */
CREATE TABLE `myt_auth_item` (
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `type` int NOT NULL,
  `description` text COLLATE utf8mb4_bin,
  `bizrule` text COLLATE utf8mb4_bin,
  `data` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_auth_item` VALUES
('Application Manager',2,NULL,NULL,'N;'),
('Developer',2,NULL,NULL,'N;'),
('Project Manager',2,NULL,NULL,'N;'),
('Role Manager',2,NULL,NULL,'N;'),
('Task Manager',2,NULL,NULL,'N;'),
('User Manager',2,NULL,NULL,'N;'),
('adminAllCharge','0','Charge Admin All',NULL,'N;'),
('adminCharge','0','Charge Admin',NULL,'N;'),
('adminConfig','0','Application Configuration Management',NULL,'N;'),
('adminRole','0','Roles Configuration Management',NULL,'N;'),
('createCharge','0','Charge Create',NULL,'N;'),
('createProject','0','Project Create',NULL,'N;'),
('createTask','0','Task Create',NULL,'N;'),
('createUser','0','User Create',NULL,'N;'),
('deleteProject','0','Project Delete',NULL,'N;'),
('deleteTask','0','Task Delete',NULL,'N;'),
('deleteUser','0','User Delete',NULL,'N;'),
('indexAllProject','0','Project View All',NULL,'N;'),
('indexAllTask','0','Task View All',NULL,'N;'),
('indexAllUser','0','User View All',NULL,'N;'),
('updateProject','0','Project Update',NULL,'N;'),
('updateTask','0','Task Update',NULL,'N;'),
('updateUser','0','User Update',NULL,'N;');
/* Scheme for table myt_auth_item_child */
CREATE TABLE `myt_auth_item_child` (
  `parent` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `child` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`parent`,`child`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_auth_item_child` VALUES
('Application Manager','adminAllCharge'),
('Application Manager','adminConfig'),
('Developer','createCharge'),
('Developer','createTask'),
('Developer','deleteTask'),
('Developer','updateTask'),
('Project Manager','adminCharge'),
('Project Manager','createCharge'),
('Project Manager','createProject'),
('Project Manager','deleteProject'),
('Project Manager','indexAllProject'),
('Project Manager','updateProject'),
('Role Manager','adminRole'),
('Task Manager','createTask'),
('Task Manager','deleteTask'),
('Task Manager','indexAllTask'),
('Task Manager','updateTask'),
('User Manager','createUser'),
('User Manager','deleteUser'),
('User Manager','updateUser');
/* Scheme for table myt_charge */
CREATE TABLE `myt_charge` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `created_by` int NOT NULL,
  `last_upd` datetime DEFAULT NULL,
  `last_upd_by` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `project_id` int DEFAULT NULL,
  `task_id` int DEFAULT NULL,
  `day` date DEFAULT NULL,
  `hours` float DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `myt_created_by` (`created_by`),
  KEY `myt_last_upd_by` (`last_upd_by`),
  KEY `myt_user_id` (`user_id`),
  KEY `myt_project_id_charge` (`project_id`),
  KEY `myt_task_id_charge` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_charge` VALUES
(1,'2024-09-14 20:37:21',1,'2024-09-14 22:44:56',1,1,5,1,'2024-09-15',1),
(2,'2024-09-14 20:37:30',1,'2024-09-14 22:44:56',1,1,5,1,'2024-09-13',1),
(3,'2024-09-14 20:37:30',1,'2024-09-14 22:44:56',1,1,5,1,'2024-09-14',1),
(4,'2024-09-14 22:44:56',1,'2024-09-14 22:44:56',1,1,6,2,'2024-09-15',1),
(5,'2024-10-06 16:44:56',1,'2024-10-06 16:44:56',1,1,6,10,'2024-10-05',1),
(6,'2024-10-06 16:44:56',1,'2024-10-06 16:44:56',1,1,6,10,'2024-10-06',0.5);
/* Scheme for table myt_comment */
CREATE TABLE `myt_comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `created_by` int NOT NULL,
  `last_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_upd_by` int DEFAULT NULL,
  `entity` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `entity_id` int NOT NULL,
  `body` text COLLATE utf8mb4_bin,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

/* Scheme for table myt_counter_save */
CREATE TABLE `myt_counter_save` (
  `save_name` varchar(10) COLLATE utf8mb4_bin NOT NULL,
  `save_value` int unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

/* Scheme for table myt_counter_users */
CREATE TABLE `myt_counter_users` (
  `user_ip` varchar(39) COLLATE utf8mb4_bin NOT NULL,
  `user_time` int unsigned NOT NULL,
  UNIQUE KEY `user_ip` (`user_ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

/* Scheme for table myt_project */
CREATE TABLE `myt_project` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `created_by` int NOT NULL,
  `last_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_upd_by` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `prefix` varchar(3) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` text COLLATE utf8mb4_bin,
  `champion_id` int DEFAULT NULL,
  `status` varchar(3) COLLATE utf8mb4_bin DEFAULT NULL,
  `progress` smallint unsigned DEFAULT NULL,
  `par_project_id` int DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `eff_start_date` date DEFAULT NULL,
  `eff_end_date` date DEFAULT NULL,
  `client` tinytext COLLATE utf8mb4_bin,
  `chargeable_flg` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `myt_par_project` (`par_project_id`),
  KEY `myt_champion` (`champion_id`),
  KEY `myt_created_by_project` (`created_by`),
  KEY `myt_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_project` VALUES
(1,'2024-09-14 20:35:14',1,'2024-09-14 20:35:14',1,'Courses','--0',NULL,1,'4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
(2,'2024-09-14 20:35:14',1,'2024-09-14 20:35:14',1,'Vacation','--1',NULL,1,'4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
(3,'2024-09-14 20:35:14',1,'2024-09-14 20:35:14',1,'Public Holiday','--2',NULL,1,'4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
(4,'2024-09-14 20:35:14',1,'2024-09-14 20:35:14',1,'Sick-leave','--3',NULL,1,'4',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
(5,'2024-09-14 20:36:32',1,'2024-09-20 06:31:00',1,'ブログ作業','PRJ',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
(6,'2024-09-14 22:18:32',1,'2024-09-15 03:39:32',1,'MyTのメンテナンス','PRA',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
(7,'2024-09-20 06:42:20',1,'2024-09-20 06:42:20',1,'テスト','PR3',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1),
(8,'2024-09-20 06:43:09',1,'2024-09-20 06:44:22',1,'test3','PRB',NULL,1,'3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1);
/* Scheme for table myt_session */
CREATE TABLE `myt_session` (
  `id` char(32) COLLATE utf8mb4_bin NOT NULL,
  `user_id` int unsigned NOT NULL,
  `expire` int DEFAULT NULL,
  `data` longblob,
  PRIMARY KEY (`id`),
  KEY `myt_user_id_session` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_session` VALUES
('0h1o3q6tuaitpa5nn5s3mnk4j0','0',1727424807,'7f3d20c8e49570aa540fa8478754d670__returnUrl|s:23:\"/prj/index.php?r=config\";'),
('6bcejto15sq40ojc829f3q5s9j',1,1728472689,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}'),
('6hhbbdu7cj2jl4d2fpv8tg1g3i',1,1728126780,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}'),
('7p5ctve6gsf2h7b9un7bo4sric','0',1728125632,NULL),
('89kabu295ncsog4es5btidoquc',1,1727792391,'7f3d20c8e49570aa540fa8478754d670__returnUrl|s:23:\"/prj/index.php?r=config\";7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}7f3d20c8e49570aa540fa8478754d670Yii.CWebUser.flash.success|s:51:\"新しいオプションが保存されました。\";7f3d20c8e49570aa540fa8478754d670Yii.CWebUser.flashcounters|a:1:{s:7:\"success\";i:1;}'),
('8gar41bkmhpcoc64hf495qe7cb',1,1728167803,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}'),
('9bt1vtj57r0bhbfaiuarpln1fl','0',1728300800,NULL),
('9jpvj28afq7tak40kqsqmrt066','0',1728300630,NULL),
('adsg2lnq4fqe74f3ltf42k3pcv',1,1727422784,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}'),
('c5jse2j6r99m1016cj7juhiem0',1,1728123293,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}'),
('f7nh3q0gup3ltr6pge6hj0bc4s','0',1727514195,NULL),
('h9989eog1g30d5f74cp5dfduro','0',1728120391,NULL),
('j7u62mpkqtvpmnu0t98l1j166b','0',1727511331,NULL),
('k8fb411f3hoksktklv4h05qt8q',1,1728167731,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}7f3d20c8e49570aa540fa8478754d670charge_query|s:0:\"\";'),
('kqqd0v7fs81or2s2rhbus41km3','0',1728204364,NULL),
('llgk3rg2265ku750qf8368r2lr','0',1728084266,NULL),
('nrfjf4mlnr8bpno9c2ga4khnk5',1,1727793277,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}'),
('osdg26reo6di2t9d0rcbk276rk','0',1727514317,NULL),
('p435pv55l67mvt455f39m1is3o',1,1727437157,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}7f3d20c8e49570aa540fa8478754d670Yii.CWebUser.flash.success|s:51:\"新しいオプションが保存されました。\";7f3d20c8e49570aa540fa8478754d670Yii.CWebUser.flashcounters|a:1:{s:7:\"success\";i:1;}'),
('pf99i3upu5reudfkfsfotil521',1,1727438901,'7f3d20c8e49570aa540fa8478754d670__returnUrl|s:23:\"/prj/index.php?r=config\";7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}'),
('qacvdbp3kuc9hqd6uen12o4jah',1,1728115432,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}'),
('r0rdmc39td4h8udoa0cbe5u51e',1,1728206791,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}7f3d20c8e49570aa540fa8478754d670task_query|s:0:\"\";7f3d20c8e49570aa540fa8478754d670charge_query|s:0:\"\";'),
('rh9fb6o33be0fk8b3s4pp361ak',1,1727514461,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:33:\"/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}7f3d20c8e49570aa540fa8478754d670Yii.CWebUser.flash.success|s:51:\"新しいオプションが保存されました。\";7f3d20c8e49570aa540fa8478754d670Yii.CWebUser.flashcounters|a:1:{s:7:\"success\";i:1;}'),
('t94l074ivmpld1og6frpqs46f2',1,1728537664,'7f3d20c8e49570aa540fa8478754d670__id|i:1;7f3d20c8e49570aa540fa8478754d670__name|s:12:\"Admin, Admin\";7f3d20c8e49570aa540fa8478754d670pageSize|i:10;7f3d20c8e49570aa540fa8478754d670username|s:5:\"admin\";7f3d20c8e49570aa540fa8478754d670avatar|s:37:\"/prj/images/user/default_avatar_M.jpg\";7f3d20c8e49570aa540fa8478754d670__states|a:3:{s:8:\"pageSize\";b:1;s:8:\"username\";b:1;s:6:\"avatar\";b:1;}7f3d20c8e49570aa540fa8478754d670navigation|a:4:{s:4:\"home\";b:1;s:7:\"project\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:4:\"task\";a:2:{s:4:\"type\";s:2:\"my\";s:2:\"id\";s:0:\"\";}s:6:\"charge\";a:1:{s:4:\"type\";s:2:\"my\";}}');
/* Scheme for table myt_task */
CREATE TABLE `myt_task` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `created_by` int NOT NULL,
  `last_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_upd_by` int DEFAULT NULL,
  `par_project_id` int NOT NULL,
  `parent_id` int DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `description` text COLLATE utf8mb4_bin,
  `status` int DEFAULT NULL,
  `progress` smallint unsigned DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `eff_start_date` date DEFAULT NULL,
  `eff_end_date` date DEFAULT NULL,
  `priority` smallint DEFAULT NULL,
  `type` smallint DEFAULT NULL,
  `private_flg` tinyint(1) NOT NULL DEFAULT '0',
  `chargeable_flg` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `myt_task_ibfk_3` (`parent_id`),
  KEY `myt_task_ibfk_2` (`created_by`),
  KEY `myt_task_ibfk_1` (`par_project_id`),
  KEY `myt_title` (`title`,`par_project_id`),
  KEY `myt_status_task` (`status`),
  KEY `myt_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_task` VALUES
(1,'2024-09-14 20:36:55',1,'2024-09-14 22:23:28',1,5,NULL,'タスク',NULL,5,NULL,'2024-09-14',NULL,NULL,NULL,1,3,'0',1),
(2,'2024-09-14 22:19:09',1,'2024-09-15 04:15:16',1,6,NULL,'パスワード忘れの時のメール送信バグ','(1) 500エラーが発生する。\r\n->\r\nphp8で発生する{}のエラー。[]に変換した\r\n\r\n(2) Error 500\r\nConnection could not be established with host smtp.zoho.jp [Unable to find the socket transport \"TLS\" - did you forget to enable it when you configured PHP? #2114010160]のエラー\r\nswiftメールのバージョンが古い！\r\n\r\nError 500\r\nCall to undefined method Swift_Message::newInstance()',1,NULL,'2024-09-14',NULL,NULL,NULL,1,1,'0',1),
(3,'2024-09-14 23:37:23',1,'2024-09-14 23:37:23',1,6,NULL,'task画面で延々とロードされる問題','原因を調べたら、multi-select-switch.png\r\nがjsで読めていなかった。パスを直した\r\n',1,NULL,'2024-09-14',NULL,NULL,NULL,1,3,'0',1),
(4,'2024-09-15 01:49:50',1,'2024-09-15 03:34:47',1,6,NULL,'xssの対処','<script>alert(\'XSS\')</script>をタイトルに入力してもアラートが出ないようにする\r\n\r\nルールに以下の内容を追加する\r\n        array(\'title\', \'filter\', \'filter\' => \'CHtml::encode\'),\r\n        array(\'title\', \'filter\', \'filter\' => \'strip_tags\'),',1,NULL,'2024-09-15',NULL,NULL,NULL,1,3,'0',1),
(5,'2024-09-20 06:32:32',36,'2024-09-20 06:35:59',36,5,NULL,'test',NULL,5,NULL,'2024-09-20',NULL,NULL,NULL,1,3,'0',1),
(6,'2024-09-20 06:35:39',36,'2024-09-20 06:36:02',36,5,NULL,'test',NULL,5,NULL,'2024-09-20',NULL,NULL,NULL,1,3,'0',1),
(7,'2024-09-20 06:36:18',36,'2024-09-20 06:36:18',36,5,NULL,'test','test',1,NULL,'2024-09-20',NULL,NULL,NULL,1,3,'0',1),
(8,'2024-09-20 06:41:08',36,'2024-09-20 06:41:08',36,5,NULL,'test2',NULL,1,NULL,'2024-09-20',NULL,NULL,NULL,1,3,'0',1),
(9,'2024-09-20 06:41:35',36,'2024-09-20 06:41:35',36,5,NULL,'test3',NULL,1,NULL,'2024-09-20',NULL,NULL,NULL,1,3,'0',1),
(10,'2024-10-06 16:44:04',1,'2024-10-06 16:44:31',1,6,NULL,'MyT用テーマの作成','Yii FactoryよりテーマをダウンロードしてMyT用テーマを作成する',1,NULL,'2024-10-06',NULL,NULL,NULL,1,3,'0',1);
/* Scheme for table myt_task_status */
CREATE TABLE `myt_task_status` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `group_id` int unsigned NOT NULL,
  `order_by` int unsigned NOT NULL,
  `default_flg` tinyint(1) DEFAULT NULL,
  `active_flg` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_task_status` VALUES
(1,'Open','0','0',1,1),
(2,'Working On','0',1,NULL,1),
(3,'Suspended',2,2,NULL,1),
(4,'Closed',1,3,NULL,1),
(5,'Cancelled',1,4,NULL,1);
/* Scheme for table myt_task_type */
CREATE TABLE `myt_task_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `order_by` int unsigned NOT NULL,
  `default_flg` tinyint(1) DEFAULT NULL,
  `active_flg` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_task_type` VALUES
(1,'Bug','0',NULL,1),
(2,'Enhancement',1,NULL,1),
(3,'Task',2,1,1);
/* Scheme for table myt_user */
CREATE TABLE `myt_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `created_by` int NOT NULL DEFAULT '1',
  `last_upd` datetime NOT NULL,
  `last_upd_by` int NOT NULL DEFAULT '1',
  `username` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(63) COLLATE utf8mb4_bin DEFAULT NULL,
  `surname` varchar(63) COLLATE utf8mb4_bin DEFAULT NULL,
  `gender` char(1) COLLATE utf8mb4_bin NOT NULL,
  `level` varchar(63) COLLATE utf8mb4_bin DEFAULT NULL,
  `phone` varchar(63) COLLATE utf8mb4_bin DEFAULT NULL,
  `mobile` varchar(63) COLLATE utf8mb4_bin DEFAULT NULL,
  `load_cost` float(7,3) DEFAULT NULL,
  `bill_code` smallint DEFAULT NULL,
  `seat_charge` float(7,3) DEFAULT NULL,
  `daily_hours` float(3,1) DEFAULT NULL,
  `profile_id` int DEFAULT NULL,
  `note` text COLLATE utf8mb4_bin,
  `confirm_key` varchar(40) COLLATE utf8mb4_bin DEFAULT NULL,
  `avatar` text COLLATE utf8mb4_bin,
  `page_size` tinyint DEFAULT NULL,
  `notifications` text COLLATE utf8mb4_bin,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `myt_profile` (`profile_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_user` VALUES
(1,'2024-09-14 20:35:14','0','2024-09-20 05:56:10','0','admin','$2y$13$t7Z5qpEfJBNZd5eNH0ltauKAvS4QpCCzFhdSQSsS8WKj.3KjI18ku','nexus6user2023132432@gmail.com',1,'Admin','Admin','M',NULL,NULL,NULL,NULL,NULL,NULL,8,NULL,NULL,'77c2fdd8e7f094a0048521305392d313adcdb4c4',NULL,NULL,'N;'),
(45,'2024-09-20 16:57:40',1,'2024-09-20 16:57:40',1,'user','$2y$10$Q6TZzGJkVsmeyvS0jv2sjOMZEnajjwbrXORVx2yeA/urE.evaaB8C','appsideus@yahoo.co.jp',1,NULL,NULL,'M',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/* Scheme for table myt_user_project */
CREATE TABLE `myt_user_project` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `last_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int NOT NULL,
  `project_id` int NOT NULL,
  `rollon_date` date DEFAULT NULL,
  `rolloff_date` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`project_id`),
  KEY `myt_user_project_ibfk_2` (`project_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_user_project` VALUES
(1,'2024-09-14 20:35:14','2024-09-14 20:35:14',1,1,'2024-09-14',NULL),
(2,'2024-09-14 20:35:14','2024-09-14 20:35:14',1,2,'2024-09-14',NULL),
(3,'2024-09-14 20:35:14','2024-09-14 20:35:14',1,3,'2024-09-14',NULL),
(4,'2024-09-14 20:35:14','2024-09-14 20:35:14',1,4,'2024-09-14',NULL),
(5,'2024-09-14 20:36:32','2024-09-14 20:36:32',1,5,'2024-09-14',NULL),
(6,'2024-09-14 22:18:32','2024-09-14 22:18:32',1,6,'2024-09-14',NULL),
(7,'2024-09-15 08:17:55','2024-09-15 08:17:55',2,1,'2024-09-15',NULL),
(8,'2024-09-15 08:17:55','2024-09-15 08:17:55',2,2,'2024-09-15',NULL),
(9,'2024-09-15 08:17:55','2024-09-15 08:17:55',2,3,'2024-09-15',NULL),
(10,'2024-09-15 08:17:55','2024-09-15 08:17:55',2,4,'2024-09-15',NULL),
(11,'2024-09-20 06:31:00','2024-09-20 06:31:00',36,5,'2024-09-20',NULL),
(12,'2024-09-20 06:42:20','2024-09-20 06:42:20',1,7,'2024-09-20',NULL),
(13,'2024-09-20 06:43:09','2024-09-20 06:43:09',1,8,'2024-09-20',NULL);
/* Scheme for table myt_user_task */
CREATE TABLE `myt_user_task` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created` datetime NOT NULL,
  `last_upd` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `user_id` int NOT NULL,
  `task_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`task_id`),
  KEY `myt_user_task_ibfk_2` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO `myt_user_task` VALUES
(1,'2024-09-15 05:36:55','2024-09-15 05:36:55',1,1),
(2,'2024-09-15 07:19:09','2024-09-15 07:19:09',1,2),
(3,'2024-09-15 08:37:23','2024-09-15 08:37:23',1,3),
(4,'2024-09-15 10:49:50','2024-09-15 10:49:50',1,4),
(5,'2024-09-20 15:32:32','2024-09-20 15:32:32',36,5),
(6,'2024-09-20 15:35:39','2024-09-20 15:35:39',36,6),
(7,'2024-09-20 15:36:18','2024-09-20 15:36:18',1,7),
(8,'2024-09-20 15:36:18','2024-09-20 15:36:18',36,7),
(9,'2024-09-20 15:41:08','2024-09-20 15:41:08',36,8),
(10,'2024-09-20 15:41:35','2024-09-20 15:41:35',36,9),
(11,'2024-10-06 16:44:04','2024-10-06 16:44:04',1,10);
